const Orders = [
    {
        productName: 'JavaScript Tutorial',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'CSS Full Course',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'Flex-Box Tutorial',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'JavaScript Tutorial',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'CSS Full Course',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'Flex-Box Tutorial',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'JavaScript Tutorial',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'CSS Full Course',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'Flex-Box Tutorial',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'JavaScript Tutorial',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'CSS Full Course',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'Flex-Box Tutorial',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'JavaScript Tutorial',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'CSS Full Course',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'Flex-Box Tutorial',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'JavaScript Tutorial',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'CSS Full Course',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'Flex-Box Tutorial',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'JavaScript Tutorial',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'CSS Full Course',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'Flex-Box Tutorial',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'JavaScript Tutorial',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'CSS Full Course',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'Flex-Box Tutorial',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'JavaScript Tutorial',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'CSS Full Course',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
    {
        productName: 'Flex-Box Tutorial',
        productNumber: 'Title',
        productDetail: 'ehh',
    },
]